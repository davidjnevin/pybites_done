INDENTS = 4


def print_hanging_indents(poem):
    pass
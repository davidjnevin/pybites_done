import json


def get_movie_data(files: list) -> list:
    """Parse movie json files into a list of dicts"""
    pass


def get_single_comedy(movies: list) -> str:
    """return the movie with Comedy in Genres"""
    pass


def get_movie_most_nominations(movies: list) -> str:
    """Return the movie that had the most nominations"""
    pass


def get_movie_longest_runtime(movies: list) -> str:
    """Return the movie that has the longest runtime"""
    pass